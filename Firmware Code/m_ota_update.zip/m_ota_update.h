#include "Arduino.h"
#include <WiFiMulti.h>
#include "m_file_class.h"
#include "onboard_led.h"

#ifndef OTA_UPDATE_CLASS_DEF
  #define OTA_UPDATE_CLASS_DEF



class OTA_UPDATE_CLASS {
  private:
    File firmware_file; 
    String* ssid;
    String* password;
    WiFiMulti wifiMulti;
    mSerial* mserial;
    ONBOARD_LED_CLASS* onboardLED;

  public:
    String firmware_filename_str;
    String firmware_version_filename_str;
    String firmware_update_url;
    String firmware_version_update_url;
    uint32_t  connectionTimeout;


    OTA_UPDATE_CLASS();

    void add_firmware_version_url(String firmware_version_update_url);
    void add_firmware_url(String firmware_update_url);
    void add_firmware_filename(String firmware_filename_str);
    void add_firmware_version_filename(String firmware_version_filename_str);

    bool init(mSerial* mserial, ONBOARD_LED_CLASS* onboardLED);

    bool check_for_firmware_updates();
    bool firmware_update();

    bool download_firmware_version();
    bool download_firmware();
    bool download_file(String filename, String url);
};

#endif