#include "m_ota_update.h"
#include <Arduino.h>
#include <WiFi.h>
#include "mserial.h"
#include <HTTPClient.h>
#include "m_math.h"
#include "Update.h"
#include "FS.h"
#include "FFat.h"

OTA_UPDATE_CLASS::OTA_UPDATE_CLASS(){

}

void OTA_UPDATE_CLASS::add_firmware_url(String firmware_update_url){
    this->firmware_update_url=firmware_update_url;
}

void OTA_UPDATE_CLASS::add_firmware_version_url(String firmware_version_update_url){
    this->firmware_version_update_url=firmware_version_update_url;
}

void OTA_UPDATE_CLASS::add_firmware_filename(String firmware_filename_str){
    this->firmware_filename_str=firmware_filename_str;
}

void OTA_UPDATE_CLASS::add_firmware_version_filename(String firmware_version_filename_str){
    this->firmware_version_filename_str=firmware_version_filename_str;
}


bool OTA_UPDATE_CLASS::init(mSerial* mserial, ONBOARD_LED_CLASS* onboardLED ){
    this->mserial= mserial;
    this->onboardLED=onboardLED;

    this->firmware_filename_str="firmware.bin";
    this->firmware_version_filename_str="version.txt";
    this->firmware_update_url="";
    this->firmware_version_update_url="";
    return true;
}


bool OTA_UPDATE_CLASS::check_for_firmware_updates(){
    if (!this->download_firmware_version()){
        return false;
    }

    File serverVersionFile = FFat.open(this->firmware_version_filename_str, "r");
    File versionFile = FFat.open("/version.local", "r");
    bool result=false;

    if (serverVersionFile){
      if (versionFile){
        String server_version = serverVersionFile.readString();
        server_version.replace(".","");
        if(isNumeric(server_version)==false){
            result=false;
        }
        
        String local_version=versionFile.readString();
        long local_ver= atol (local_version.c_str());
        long server_ver = atol(server_version.c_str());
        if (local_ver<server_ver){
            result=true;
        }
      }else{
        result = true;
      }
    }else{
      this->mserial->printStrln("Error reading file !");
      this->onboardLED->statusLED( (uint8_t*)(const uint8_t[]){this->onboardLED->LED_RED}, 100,5); 
    }

    versionFile.close();
    this->mserial->printStrln("-- Reading version File completed --");
    return result;
}

bool OTA_UPDATE_CLASS::firmware_update(){
    bool result = this->check_for_firmware_updates();
    if (result){
        result= this->download_file(this->firmware_filename_str, this->firmware_update_url);
        // do firmware update
        File firmwareFile = FFat.open(this->firmware_filename_str, "r");
        if (!firmwareFile){
            this->mserial->printStrln("Error reading firmwaare file !");
            this->onboardLED->statusLED( (uint8_t*)(const uint8_t[]){this->onboardLED->LED_RED}, 100,5); 
            return false;
        }
        size_t fileSize = firmwareFile.size();
        if(!Update.begin(fileSize)){
            this->mserial->printStrln("Cannot do the update");
            return false;
        };
        
        Update.writeStream(firmwareFile);
 
        if(Update.end()){   
            this->mserial->printStrln("Successful update");  
        }else {
            this->mserial->printStrln("Error Occurred: " + String(Update.getError()));
            return false;
        }
        firmwareFile.close();

        this->mserial->printStrln("Reset in 4 seconds...");
        delay(4000);
        ESP.restart();
        return true;
        // ToDo firmware upgrade
    }
}

bool OTA_UPDATE_CLASS::download_firmware_version(){
    return this->download_file(this->firmware_version_filename_str, this->firmware_version_update_url);

}

bool OTA_UPDATE_CLASS::download_firmware(){
   return this->download_file(this->firmware_filename_str, this->firmware_update_url);

}

bool OTA_UPDATE_CLASS::download_file(String filename, String url){
    // wait for WiFi connection
    if((wifiMulti.run() == WL_CONNECTED)) {
        HTTPClient http;
        File firmwareFile = FFat.open(filename, "w"); //  /firmware.bin
        // configure server and url
        http.begin(url,80);
        
        // start connection and send HTTP header
        int httpCode = http.GET();
        if(httpCode > 0) {
            // file found at server
            if(httpCode == HTTP_CODE_OK) {
                // get length of document (is -1 when Server sends no Content-Length header)
                int len = http.getSize();
                if (len==-1){
                    this->mserial->printStrln("No content file found");
                    return false;
                }
                // check for flash space
                if (len >= FFat.freeBytes()){
                    this->mserial->printStrln("not enough free space on the OTA storage drive");
                    return false;
                }
                // create buffer for read
                uint8_t buff[128] = { 0 };

                // get tcp stream
                WiFiClient * stream = http.getStreamPtr();

                // read all data from server
                while(http.connected() && (len > 0 || len == -1)) {
                    // get available data size
                    size_t size = stream->available();

                    if(size) {
                        // read up to 128 byte
                        int c = stream->readBytes(buff, ((size > sizeof(buff)) ? sizeof(buff) : size));

                        // write it to Serial
                        firmwareFile.write(buff,c);

                        if(len > 0) {
                            len -= c;
                        }
                    }
                    delay(1);
                }
                this->mserial->printStrln("[HTTP] connection closed or file end.");
                firmwareFile.close();
            }
        } else {
            this->mserial->printStrln("[HTTP] GET... failed, error: " + http.errorToString(httpCode));
            return false;
        }
        http.end();
        return true;
    }
}
